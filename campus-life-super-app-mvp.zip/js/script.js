
// script.js - starter JavaScript for Campus Life MVP
// Comments explain what each function does for the instructor review

// Set the year in the footer(s)
document.addEventListener('DOMContentLoaded', function () {
  const y = new Date().getFullYear();
  const ys = document.getElementById('year');
  if (ys) ys.textContent = y;
  const ym = document.getElementById('year-map');
  if (ym) ym.textContent = y;
  const ys2 = document.getElementById('year-sports');
  if (ys2) ys2.textContent = y;

  // Attach event listeners for placeholder buttons
  const refreshBtn = document.getElementById('refresh-data');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', function () {
      // Example of event-driven programming - fetch placeholder events
      loadFeaturedEvents();
    });
  }

  const scoresBtn = document.getElementById('load-scores');
  if (scoresBtn) {
    scoresBtn.addEventListener('click', function () {
      // Placeholder - would fetch scores from an API in the final project
      alert('This will fetch latest scores from the API (not implemented in MVP).');
    });
  }
});

// Placeholder function showing where API integration will happen
function loadFeaturedEvents() {
  const eventsList = document.getElementById('events-list');
  if (!eventsList) return;
  // This is a placeholder / mock. In the final project replace with a real API URL.
  // fetch('https://api.example.com/events')
  //   .then(resp => resp.json())
  //   .then(data => renderEvents(data))
  //   .catch(err => console.error('API error', err));

  // Mock data for MVP display
  const mock = [
    { title: 'Welcome Back BBQ', date: '2025-09-02' },
    { title: 'Club Fair', date: '2025-09-10' }
  ];
  eventsList.innerHTML = mock.map(e => `<div><strong>${e.title}</strong> — ${e.date}</div>`).join('');
}

// OPTIONAL: function to render events from a real API
function renderEvents(data) {
  const eventsList = document.getElementById('events-list');
  if (!eventsList) return;
  // Example mapping - adapt to real API response structure
  eventsList.innerHTML = data.map(e => `<div><strong>${e.title}</strong> — ${e.date}</div>`).join('');
}
